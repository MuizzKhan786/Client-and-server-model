import java.io.*;
import java.net.*;

public class client {
    public static void main(String[] args) {
        try {
            // Connect to the server running on localhost at port 5000
            Socket socket = new Socket("localhost", 5000);
            // Read input from console
            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
            // Read server responses
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            // Send messages to server
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            System.out.println("Connected to server. Type messages:");

            String input;
            while ((input = userInput.readLine()) != null) {
                out.println(input); // send to server
                String response = in.readLine(); // receive from server
                System.out.println("Server: " + response);
            }

            socket.close();
        } catch (IOException e) {
            System.out.println("Client Error: " + e.getMessage());// Print error if connection fails

        }
    }
}

