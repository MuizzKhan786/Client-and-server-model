import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class clientGUI extends JFrame {
    Socket socket;
    PrintWriter out;
    BufferedReader in;

    JTextArea chatArea;
    JTextField inputField;
    JButton sendButton;

    public clientGUI() {
        setTitle("Client");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        chatArea = new JTextArea();
        chatArea.setEditable(false);
        add(new JScrollPane(chatArea), BorderLayout.CENTER);
        // Input field and button panel
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputField = new JTextField();
        sendButton = new JButton("Send");

        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);
        add(inputPanel, BorderLayout.SOUTH);

        sendButton.addActionListener(e -> sendMessage());
        inputField.addActionListener(e -> sendMessage());

        connectToServer();// Establish connection

        setVisible(true);
    }

    private void connectToServer() {
        try {
            socket = new Socket("localhost", 5050);//port
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            // Read incoming messages 
            new Thread(() -> {
                try {
                    String response;
                    while ((response = in.readLine()) != null) {
                        chatArea.append("Server: " + response + "\n");
                    }
                } catch (IOException e) {
                    chatArea.append("Disconnected.\n");
                }
            }).start();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Cannot connect to server.");
            System.exit(0);
        }
    }

    private void sendMessage() {
        String message = inputField.getText().trim();
        if (!message.isEmpty()) {
            out.println(message);// Send to server
            chatArea.append("You: " + message + "\n");// Show in chat area
            inputField.setText("");// Clear input
        }
    }

    public static void main(String[] args) {
        new clientGUI();// Launch the GUI
    }
}
