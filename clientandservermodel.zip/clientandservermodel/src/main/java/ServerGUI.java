import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;

public class ServerGUI extends JFrame {

    private JLabel statusLabel;
    private ServerSocket serverSocket;

    public ServerGUI() {
        setTitle("Java Server");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        statusLabel = new JLabel("Waiting to start server...", SwingConstants.CENTER);
        add(statusLabel, BorderLayout.CENTER);

        setVisible(true);

        startServer();
    }

    private void log(String message) {
        System.out.println(message);
    }

    private void startServer() {
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(5050);
                log("Server started on port 5050. Waiting for client...");
                statusLabel.setText("Waiting for client...");
                Socket clientSocket = serverSocket.accept();
                log("Client connected.");
                statusLabel.setText("Status:Client connected.");

                BufferedReader in = new BufferedReader(
                        new InputStreamReader(clientSocket.getInputStream())
                );
                PrintWriter out = new PrintWriter(
                        clientSocket.getOutputStream(), true
                );

                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    log("Received: " + inputLine);

                    String response;
                    if (inputLine.matches(".*[\\$@!].*")) {
                        response = "Error: Invalid message.";
                    } else if (inputLine.equalsIgnoreCase("hi")) {
                        response = "hello";
                    } else if (inputLine.equalsIgnoreCase("how are you")) {
                        response = "I'm a server, always perfect!";
                    } else if (inputLine.equalsIgnoreCase("can i ask about something")){
                        response = "yeah why not, you can ask:";
                    } else if (inputLine.equalsIgnoreCase ("hey one more thing can i use urdu language")){
                        response = "hmmm yeah i can understand some words like greetings";
                    } else if (inputLine.equalsIgnoreCase("ok fine i will use urdu for greetings")){
                        response = "ok sure";
                    } else {
                        response = "You said: " + inputLine;
                    }

                    out.println(response);
                    log("Sent: " + response);
                }

                log("Client has disapeared");
                statusLabel.setText("Status: Client disapeared.");
                clientSocket.close();

            } catch (IOException e) {
                e.printStackTrace();
                log(" Server error: " + e.getMessage());
                statusLabel.setText("Status: Server error.");
            }
        }).start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ServerGUI::new);
    }
    
}
